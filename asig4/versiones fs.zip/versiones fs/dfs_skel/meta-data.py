###############################################################################
#
# Filename: meta-data.py
# Author: Jose R. Ortiz and ... (hopefully some students contribution)
#
# Description:
# 	MySQL support library for the DFS project. Database info for the 
#       metadata server.
#
# Please modify globals with appropiate info.

from mds_db import *
from Packet import *
import sys
import socketserver
import os

def usage():
	print("Usage: python %s <port, default=8000>" % sys.argv[0]) 
	sys.exit(0)

def encode(p):
	''' Encodes the packet and makes it a bytes string to send'''
	p = Packet.getEncodedPacket(p)
	p = p.encode('utf-8')
	return p


def recvall(sock,size):
	''' Continues recieving until it has recieved everything'''
	msg = b''
	while len(msg)!= size:
		chunk = sock.recv(1024)
		msg += chunk
	return msg

def sendSize(sock,size):
	''' send the size of the block '''

	d = Packet()
	d.BuildBlockSize(size)
	sock.sendall(encode(d))
	msg = sock.recv(1024)
	msg = msg.decode('utf-8')
	return msg

def recieveSize(sock):
		''' recieve the size of the block  '''

		p = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		p.DecodePacket(recieved)
		return p.getPacketSize()


class MetadataTCPHandler(socketserver.BaseRequestHandler):

	def handle_reg(self, db, p):
		"""Register a new client to the DFS ACK if successfully REGISTERED
			NAK if problem, DUP if the IP and port already registered
		"""

		try:

			address,port= p.getAddr(),p.getPort()

			if mds_db.AddDataNode(db,address, port): #fill:
				# if data node not in GetDataNodes()
				
				self.request.sendall("ACK".encode('utf-8'))

			else:
				# if data in GetDataNodes(), handle_get also checks the nodes
				self.request.sendall("DUP".encode('utf-8'))

		except:
			self.request.sendall("NAK".encode('utf-8'))

	def handle_list(self, db):
		"""Get the file list from the database and send list to client"""
		try:
			# Fill code here
			
			p = Packet()
			p.BuildListResponse(mds_db.GetFiles(db))
			p = encode(p)
			msg = sendSize(self.request,len(p))
			if msg == "NAK":
				print("Unable to send list packet")
				raise
			else:
				self.request.sendall(p)

		except:
			self.request.sendall("NAK".encode('utf-8'))	

	def handle_put(self, db, p):
		"""Insert new file into the database and send data nodes to save
		   the file.
		"""
	    
		# Fill code
		info = p.getFileInfo()
		digests = p.getHash()
	
		if db.InsertFile(info[0], info[1],digests):
		
			p = Packet()
			p.BuildPutResponse(mds_db.GetDataNodes(db))
			self.request.sendall(encode(p))
			
		else:
			self.request.sendall("DUP".encode('utf-8'))
	
	def handle_get(self, db, p):
		"""Check if file is in database and return list of
			server nodes that contain the file.
		"""

		# Fill code to get the file name from packet and then 
		# get the fsize and array of metadata server
		fname = p.getFileName()
		fsize, metalist, digests = mds_db.GetFileInode(db,fname)

		if fsize and metalist:
			# Create Get response packet 
			p = Packet()
			p.BuildGetResponse(metalist, fsize,digests)
			p = encode(p)
			
			#Send size of packet
			msg = sendSize(self.request,len(p))
			if msg != 'NAK':
				# Send packet
				self.request.sendall(p)
			else:
				print("file-nodes not sent")
		else:
			self.request.sendall("NFOUND".encode('utf-8'))

	def handle_blocks(self, db, p):
		"""Add the data blocks to the file inode"""

		# Fill code to get file name and blocks from
		fname, blocks = p.getFileName(), p.getDataBlocks()
		# Fill code to add blocks to file inode
		mds_db.AddBlockToInode(db, fname, blocks)

	def handle_remove(self,db,p):
		"""Remove the file and send the metalist to remove file chunks."""
		fname = p.getFileName()
		if db.RemoveFile(fname):
			print("Successfully removed %s"%fname)
		else:
			print("Couldn't Remove file.")


	def handle_move(self,db,p):
		fname = p.getFileName()
		if db.MoveFile(fname[0],fname[1]):
			print("Successfully moved %s to %s"%(fname[0],fname[1]))
		else:
			print("Couldn't Move file.")

		
	def handle(self):

		# Recieve the packetsize
		size = recieveSize(self.request)
		
		if not size:
			self.request.sendall("NAK".encode('utf-8'))
		else:
			self.request.sendall("OK".encode('utf-8'))

			if os.path.isfile("dfs.db"):
				# Establish a connection with the local database
				db = mds_db("dfs.db")
				db.Connect()
			else:
				sys.exit("Database isn't created.")

			# Define a packet object to decode packet messages
			p = Packet()

			# recieve full message from the list, data-node, or copy clients
			msg = recvall(self.request,size)
			# Decode utf-8
			msg = msg.decode('utf-8')
			print(msg, type(msg))
			
			# Decode the packet received
			p.DecodePacket(msg)
		
			# Extract the command part of the received packet
			cmd = p.getCommand()

			# Invoke the proper action 
			if   cmd == "reg":
				# Registration client
				self.handle_reg(db, p)

			elif cmd == "list":
				# Client asking for a list of files
				# Fill code
				data = self.handle_list(db)

			
			elif cmd == "put":
				# Client asking for servers to put data
				# Fill code
				self.handle_put(db, p)

			elif cmd == "get":
				# Client asking for servers to get data
				# Fill code
				self.handle_get(db, p)


			elif cmd == "dblks":
				# Client sending data blocks for file
				# Fill code
		
				self.handle_blocks(db, p)

			elif cmd == "remove":
				# Client want's to remove
				self.handle_remove(db,p)

			elif cmd == "move":
				# client wants to rename file and move it
				self.handle_move(db,p)

			db.Close()

if __name__ == "__main__":
    HOST, PORT = "", 8000

    if len(sys.argv) > 1:
    	try:
    		PORT = int(sys.argv[1])
    	except:
    		usage()

    server = socketserver.TCPServer((HOST, PORT), MetadataTCPHandler)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
