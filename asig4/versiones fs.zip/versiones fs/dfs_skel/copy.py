###############################################################################
#
# Filename: mds_db.py
# Author: Jose R. Ortiz and ... (hopefully some students contribution)
#
# Description:
# 	Copy client for the DFS
#
#
import hashlib

import socket
import sys
import os.path

from Packet import *

def usage():
	print("Usage:\n\tFrom DFS: python %s <server>:<port>:<dfs file path> <destination file>\n\tTo   DFS: python %s <source file> <server>:<port>:<dfs file path>" % (sys.argv[0], sys.argv[0]))
	sys.exit(0)

def encode(p):
	''' Encodes the packet and makes it a bytes string to send'''
	p = Packet.getEncodedPacket(p)
	p = p.encode('utf-8')
	return p


def recvall(sock,size):
	''' Continues recieving until it has recieved everything'''
	msg = b''
	while len(msg)!= size:
		chunk = sock.recv(1024)
		msg += chunk
	return msg

def sendSize(sock,size):
	''' send the size of the block '''

	d = Packet()
	d.BuildBlockSize(size)
	sock.sendall(encode(d))
	msg = sock.recv(1024)
	msg = msg.decode('utf-8')
	return msg

def recieveSize(sock):
		''' recieve the size of the block  '''

		p = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		p.DecodePacket(recieved)
		return p.getPacketSize()

def getChunkSize(fsize):
	''' Decides chuncksize of data to use, to change 
	size of chunks only need to change this function '''

	if fsize < 1024:	            # Handle Bytes (B)
		chunksize = fsize			# Same size
	elif fsize < 32768:			    # For less than 32 KB 2**15
		chunksize = 4				# Use 4K
	elif fsize < 33554432:	        # Handle KB 2**25
		chunksize = 32768    	    # 32 KB
	elif fsize < 1073741824:        # Handle MB 2**30
		chunksize = 131072   	    # 131 KB 2**17
	else:							# Handle GB and more
		chunksize = 524288   		# 524 KB 2**19
	return chunksize

def ComputeHash(path):
	BLOCKSIZE = 4096
	hasher = hashlib.md5()
	with open(path, 'rb') as afile:
	    buf = afile.read(BLOCKSIZE)
	    while len(buf) > 0:
	        hasher.update(buf)
	        buf = afile.read(BLOCKSIZE)
	return hasher.hexdigest()


def copyToDFS(address, fname, path):
	""" Contact the metadata server to ask to copy file fname,
	    get a list of data nodes. Open the file in path to read,
	    divide in blocks and send to the data nodes. 
	"""

	# Compute hash
	digests = ComputeHash(path)

	# Create a connection to the data server
	try:
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect(address)

		# Get file size
		fsize = os.path.getsize(path)

		# Create a Put packet with the fname and the file size,
		# and sends it to the metadata server

		p = Packet()
		p.BuildPutPacket(fname, fsize,digests)

		# Encode it to send
		p = encode(p)

		#Send size of packet
		msg = sendSize(sock,len(p))
		if msg == 'NAK':
			sys.exit("error")

		# Send Packet
		sock.sendall(p)
	
		# If no error or file exists
		# Get the list of data nodes.
		# Divide the file in blocks
		# Send the blocks to the data servers

		p = Packet()
		recieved = sock.recv(1024)
		sock.close()
	
	except:
		sock.close()
		sys.exit("bad")
		
	# decodes the packet and verify if duplicate file or error
	recieved = recieved.decode('utf-8')

	if recieved == "DUP":
		sys.exit("The file already exists.")
	
	p.DecodePacket(recieved)
	
	# get data nodes from packet
	dnodes = p.getDataNodes()

	# Holds the list of dnodes order
	metalist = []
	# Position in where we insert
	x = 0

	# Determine the chunksize 
	chunksize = getChunkSize(fsize)

	# Read file
	with open(path,'rb') as file:
		# Read a chunk of file
		byte = file.read(chunksize)
		size = len(byte)
		error = False

		try:
			# executes until the file is read
			while byte:
				# Connect to the data nodes 
				sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				# connect to data node in position x
				sock.connect(tuple(dnodes[x]))
				
				# Send the size of the bytes to send
				dummy = Packet()

				dummy.BuildPutChunk(size)
				sock.sendall(encode(dummy))

				msg = sock.recv(1024)
				msg = msg.decode('utf-8')

				# if it was recieved we send the bytes
				if msg == "OK":
					# Send file
					sock.sendall(byte)
					
					# Recv the blockid
					blockid = sock.recv(1024)
					
					# Holds the list of dnodes order
					metalist.append([dnodes[x][0],dnodes[x][1],blockid.decode('utf-8')])
					
					# Update the nodes pointer
					x = (x+1)%len(dnodes)

					# Done recving so we end sock
					sock.close()

					# Update the bytes and the size 
					byte = file.read(chunksize)
					size = len(byte)
				else:
					# exit if something bad happened
					print("A chunk went rogue. Metalist to remove %s "%metalist)
					error = True
					raise
		finally:
			if error:
				try:
					sock.close()
				finally:
					print("Remove the file, something wrong.")
			# Notify the metadata server where the blocks are saved.
			# In case there was error so that it can be removed and 
			# if no error to know where the files are.

			p = Packet()
			p.BuildDataBlockPacket(fname, metalist)
			p = encode(p)

			try:
				sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				sock.connect(address)
				
				#Send size of packet
				msg = sendSize(sock,len(p))

				if msg == 'NAK':
					print("Metadata didn't recieve the packet size.")
					raise
				
				sock.sendall(p)
				sock.close()
			
			except:
				sock.close()
				sys.exit("Error")



	
def copyFromDFS(address, fname, path):
	""" Contact the metadata server to ask for the file blocks of
    the file fname.  Get the data blocks from the data nodes.
    Saves the data in path.
	"""
   	# Contact the metadata server to ask for information of fname

	data = Packet()
	data.BuildGetPacket(fname)
	data = encode(data)

	try:
		# Connect to server and send data
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect(address)

		#Send size of packet
		msg = sendSize(sock,len(data))

		if msg == 'NAK':
			print("metadata didn't recieve the packet size.")
			raise

		# Send packet
		sock.sendall(data)

		# Receive data from the server 
		data = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		
		# If there is no error response Retreive the data blocks
		if recieved == "NFOUND":
			print("File not found.")
			raise

		data.DecodePacket(recieved)
		
		# get node list size
		size = data.getPacketSize()
		if not size:
			sock.sendall("NAK".encode('utf-8'))
			print("Size of the file chunk list not recived")
			raise

		sock.sendall("OK".encode('utf-8'))
		data = Packet()
		recieved = recvall(sock,size)
		recieved = recieved.decode('utf-8')
		data.DecodePacket(recieved)

		data_nodes = data.getDataNodes()
		original_digests = data.getHash()
		with open(path,'wb') as file:
			for address,port,blockid in data_nodes:
				sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				sock.connect((address,port))

				# Make a packet sending the block
				p = Packet()
				p.BuildGetDataBlockPacket(blockid)
				sock.sendall(encode(p))

				# Recieve size of Packet
				size = recieveSize(sock)
				# Send NAK if error
				if not size:
					sock.sendall("NAK".encode('utf-8'))
					print("Size of Packet not recieved")
					raise
				else:
					# send the OK
					sock.sendall("OK".encode('utf-8'))
					# recieve the file
					byte = recvall(sock,size)
					# file.write(whatever)
					file.write(byte)

					# close the socket connection
					sock.close()

		new_file_digests = ComputeHash(path)

		if original_digests != new_file_digests:
			print("Not original file")
			raise

		print("The file is the same as the original.")
		sock.close()

	except:
		sock.close()
		sys.exit()


if __name__ == "__main__":
#	client("localhost", 8000)
	if len(sys.argv) < 3:
		usage()

	file_from = sys.argv[1].split(":")
	file_to = sys.argv[2].split(":")

	if len(file_from) > 1:
		ip = file_from[0]
		port = int(file_from[1])
		from_path = file_from[2]
		to_path = sys.argv[2]

		if os.path.isdir(to_path):
			print("Error: path %s is a directory.  Please name the file." %to_path)
			usage()

		copyFromDFS((ip, port), from_path, to_path)

	elif len(file_to) > 2:
		ip = file_to[0]
		port = int(file_to[1])
		to_path = file_to[2]
		from_path = sys.argv[1]

		if os.path.isdir(from_path):
			print("Error: path %s is a directory.  Please name the file." %from_path)
			usage()
		
		if not os.path.isfile(from_path):
			print("The file in path %s can't be read."%from_path)
			usage()

		copyToDFS((ip, port), to_path, from_path)


