###############################################################################
#
# Filename: data-node.py
# Author: Jose R. Ortiz and ... (hopefully some students contribution)
#
# Description:
# 	data node server for the DFS
#

from Packet import *

import sys
import socket
import socketserver
import uuid
import os

def usage():
	print("Usage: python %s <server> <port> <data path> <metadata port,default=8000>" % sys.argv[0]) 
	sys.exit(0)


def encode(p):
	''' Encodes the packet and makes it a bytes string to send'''
	p = Packet.getEncodedPacket(p)
	p = p.encode('utf-8')
	return p


def recvall(sock,size):
	''' Continues recieving until it has recieved everything'''
	msg = b''
	while len(msg)!= size:
		chunk = sock.recv(1024)
		msg += chunk
	return msg

def sendSize(sock,size):
	''' send the size of the block '''

	d = Packet()
	d.BuildBlockSize(size)
	sock.sendall(encode(d))
	msg = sock.recv(1024)
	msg = msg.decode('utf-8')
	return msg

def register(meta_ip, meta_port, data_ip, data_port):
	"""Creates a connection with the metadata server and
	   register as data node
	"""

	try:
		# Establish connection
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect((meta_ip,meta_port))
		
		# Won't change until data node registers
		response = "NAK"
		
		data = Packet()
		data.BuildRegPacket(data_ip, data_port)
		data = encode(data)

		#Send size of packet
		msg = sendSize(sock,len(data))

		if msg == 'NAK':
			raise

		# Send Packet
		
		while response == "NAK":

			sock.sendall(data)
			response = sock.recv(1024)
			response = response.decode('utf-8')
			
			if response == "DUP":
				print("Duplicate Registration")
			
			elif response == "NAK":
				print("Registratation ERROR")

	except:
		sock.close()
		sys.exit("Couldn't connect to metadata.")
	

class DataNodeTCPHandler(socketserver.BaseRequestHandler):

	def handle_put(self, p):

		"""Receives a block of data from a copy client, and 
		   saves it with an unique ID.  The ID is sent back to the
		   copy client.
		"""	
		self.request.sendall("OK".encode('utf-8'))

		# Generates an unique block id.
		blockid = str(uuid.uuid1())

		# recv all the data block that was sent
		byte = recvall(self.request,p.getChunkSize())
		
		# get the path name to the new data block
		filename = os.path.join(DATA_PATH,blockid)

		# Open the file for the new data block.  
		with open(filename, 'wb') as file:
			# write the bytes to the new file
			file.write(byte)
		# send the blockid to the copy client
		self.request.sendall(blockid.encode('utf-8'))
		


	def handle_get(self, p):
		
		# Get the block id from the packet
		blockid = p.getBlockID()

		# merge the DATA_PATH to the filename 
		filename = os.path.join(DATA_PATH,blockid)

		# read all the file with size getsize
		chunksize = os.path.getsize(filename)
	
		# used to read the file		
		byte = ''
		# open the file
		with open(filename,'rb') as file: 
			# read all the file
			byte = file.read(chunksize)

			# Send byte size
			msg = sendSize(self.request,len(byte))
			if msg == "OK":
				self.request.sendall(byte)
			else:
				self.request.close()

	def handle_remove(self,p):

		# Get the block id from the packet
		blockid = p.getBlockID()
		# merge the DATA_PATH to the filename 
		filename = os.path.join(DATA_PATH,blockid)
		
		# remove 
		try:
			if os.path.isfile(filename):
				os.remove(filename)
				self.request.sendall("OK".encode('utf-8'))
			else:
				self.request.sendall("NO".encode('utf-8'))
		except:
			self.request.sendall("NAK".encode('utf-8'))


	def handle(self):
		msg = self.request.recv(1024)
		msg = msg.decode('utf-8')

		print(msg, type(msg))

		p = Packet()
		p.DecodePacket(msg)

		cmd = p.getCommand()
		if cmd == "put":
			self.handle_put(p)

		elif cmd == "get":
			self.handle_get(p)
		elif cmd == "remove":
			self.handle_remove(p)
		
if __name__ == "__main__":

	META_PORT = 8000
	if len(sys.argv) < 4:
		usage()

	try:
		HOST = sys.argv[1]
		PORT = int(sys.argv[2])
		DATA_PATH = sys.argv[3]

		if len(sys.argv) > 4:
			META_PORT = int(sys.argv[4])

		if not os.path.isdir(DATA_PATH):
			print("Error: Data path %s is not a directory." % DATA_PATH)
			usage()
	except:
		usage()


	register("localhost", META_PORT, HOST, PORT)
	server = socketserver.TCPServer((HOST, PORT), DataNodeTCPHandler)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
	server.serve_forever()
