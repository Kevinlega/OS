###############################################################################
#
# Filename: mds_db.py
# Author: Jose R. Ortiz and ... (hopefully some students contribution)
#
# Description:
# 	List client for the DFS
#

import socket
import sys

from Packet import *

def usage():
	print("Usage: python %s <server>:<port>:<dfs file path> <new_filename>" %sys.argv[0]) 
	sys.exit(0)

def encode(p):
	''' Encodes the packet and makes it a bytes string to send'''
	p = Packet.getEncodedPacket(p)
	p = p.encode('utf-8')
	return p


def recvall(sock,size):
	''' Continues recieving until it has recieved everything'''
	msg = b''
	while len(msg)!= size:
		chunk = sock.recv(1024)
		msg += chunk
	return msg

def sendSize(sock,size):
	''' send the size of the block '''

	d = Packet()
	d.BuildBlockSize(size)
	sock.sendall(encode(d))
	msg = sock.recv(1024)
	msg = msg.decode('utf-8')
	return msg

def recieveSize(sock):
		''' recieve the size of the block  '''

		p = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		p.DecodePacket(recieved)
		return p.getPacketSize()

def client(ip, mport,file_mv,new_filename):
	# contact code for list in meta-data
	# Receive a msg from the list, data-node, or copy clients
		# msg = self.request.recv(1024)
		# print msg, type(msg)

	# Contacts the metadata server and ask for list of files.

	data = Packet()
	data.BuildMove(file_mv,new_filename)
	data = encode(data)

	try:
		# Connect to server and send data
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect((ip,mport))

		#Send size of packet
		msg = sendSize(sock,len(data))

		if msg == 'NAK':
			print("metadata didn't recieve the packet size.")
			raise

		# Send packet
		sock.sendall(data)
		msg = sock.recv(1024)
		msg = msg.decode('utf-8')
		if msg == "NAK":
			raise
		else:
			print("Moved")
		sock.close()

	except:
		sock.close()
		sys.exit("Error")


if __name__ == "__main__":

	if len(sys.argv) != 3:
		usage()

	file_mv = sys.argv[1].split(":")
	new_filename = sys.argv[2]

	if len(file_mv) == 2:
		ip = file_mv[0]
		port = 8000
		file_mv = file_mv[1]
	elif len(file_mv) == 3:
		ip = file_mv[0]
		port = int(file_mv[1])
		file_mv = file_mv[2]

	if not ip or not file_mv or not new_filename:
		usage()


	client(ip, port,file_mv,new_filename)
