###############################################################################
#
# Filename: mds_db.py
# Author: Jose R. Ortiz and ... (hopefully some students contribution)
#
# Description:
# 	List client for the DFS
#

import socket
import sys

from Packet import *

def usage():
	print("Usage: python %s <server>:<port>:<dfs file path>" %sys.argv[0]) 
	sys.exit(0)

def encode(p):
	''' Encodes the packet and makes it a bytes string to send'''
	p = Packet.getEncodedPacket(p)
	p = p.encode('utf-8')
	return p


def recvall(sock,size):
	''' Continues recieving until it has recieved everything'''
	msg = b''
	while len(msg)!= size:
		chunk = sock.recv(1024)
		msg += chunk
	return msg

def sendSize(sock,size):
	''' send the size of the block '''

	d = Packet()
	d.BuildBlockSize(size)
	sock.sendall(encode(d))
	msg = sock.recv(1024)
	msg = msg.decode('utf-8')
	return msg

def recieveSize(sock):
		''' recieve the size of the block  '''

		p = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		p.DecodePacket(recieved)
		return p.getPacketSize()

def client(ip, mport,file_rm):
	# contact code for list in meta-data
	# Receive a msg from the list, data-node, or copy clients
		# msg = self.request.recv(1024)
		# print msg, type(msg)

	# Contacts the metadata server and ask for list of files.

	data = Packet()
	data.BuildGetPacket(file_rm)
	data = encode(data)

	try:
		# Connect to server and send data
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect((ip,mport))

		#Send size of packet
		msg = sendSize(sock,len(data))

		if msg == 'NAK':
			print("metadata didn't recieve the packet size.")
			raise

		# Send packet
		sock.sendall(data)

		# Receive data from the server 
		data = Packet()
		recieved = sock.recv(1024)
		recieved = recieved.decode('utf-8')
		
		# If there is no error response Retreive the data blocks
		if recieved == "NFOUND":
			print("File not found.")
			raise

		data.DecodePacket(recieved)
		
		# get node list size
		size = data.getPacketSize()
		if not size:
			sock.sendall("NAK".encode('utf-8'))
			print("Size of the file chunk list not recived")
			raise

		sock.sendall("OK".encode('utf-8'))
		data = Packet()
		recieved = recvall(sock,size)
		recieved = recieved.decode('utf-8')
		data.DecodePacket(recieved)
		data_nodes = data.getDataNodes()

		missed = False

		for address,port,blockid in data_nodes:
			sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			sock.connect((address,port))

			# Make a packet sending the block
			p = Packet()
			p.BuildRemove(blockid,file_rm)
			sock.sendall(encode(p))

			# Recieve size of Packet
			msg = sock.recv(1024)
			msg = msg.decode('utf-8')

			if msg == "NAK":
				print("Couldn't delete chunk of file.")
				missed= True
			elif msg == "NO":
				print("Chunk already missing")
				
			sock.close()
		if not missed:
			# Contact the metadata when all chunks are deleted to remove file from system
			sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			sock.connect((ip,mport))
			p = Packet()
			p.BuildRemove(blockid,file_rm)
			p = encode(p)
			#Send size of packet
			msg = sendSize(sock,len(p))

			if msg == 'NAK':
				print("metadata didn't recieve the packet size.")
				raise

			# Send packet
			sock.sendall(p)



	except:
		sock.close()
		sys.exit("bad")
	print("Removed")


if __name__ == "__main__":

	if len(sys.argv) != 2:
		usage()

	file_rm = sys.argv[1].split(":")

	if len(file_rm) == 2:
		ip = file_rm[0]
		port = 8000
		file_rm = file_rm[1]
	elif len(file_rm) == 3:
		ip = file_rm[0]
		port = int(file_rm[1])
		file_rm = file_rm[2]

	if not ip or not file_rm:
		usage()

	client(ip, port,file_rm)
